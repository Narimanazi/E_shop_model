default_app_config = 'eshop_products.apps.EshopProductsConfig'
