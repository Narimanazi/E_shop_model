default_app_config = 'eshop_tag.apps.EshopTagConfig'
