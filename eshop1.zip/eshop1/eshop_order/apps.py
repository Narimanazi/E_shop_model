from django.apps import AppConfig


class EshopOrderConfig(AppConfig):
    name = 'eshop_order'
    verbose_name = 'ماژول سبد خرید'
