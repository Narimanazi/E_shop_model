from django.contrib import admin

from .models import Slider

admin.site.register(Slider)
